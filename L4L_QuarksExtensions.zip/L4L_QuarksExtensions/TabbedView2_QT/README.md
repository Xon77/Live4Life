#TabbedView2_QT
A Quark for the SuperCollider Programming Language

Important QT Additions for the TabbedView2 Quark