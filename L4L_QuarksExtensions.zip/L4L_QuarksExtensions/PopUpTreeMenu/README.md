a [Quark](https://supercollider-quarks.github.io/quarks/) for [SuperCollider](https://supercollider.github.io)

# PopUpTreeMenu
A hierarchical PopUp menu.

![PopUpTreeMenu screenshot](HelpSource/Images/PopUpTreeMenu-screenshot.png)

## Installation

Install it from within SuperCollider with the command: `Quarks.install("PopUpTreeMenu")`

The previous version (not recommended) is still available: `Quarks.install("PopUpTreeMenu", "tags/1.1.0");`

## Basic usage

```supercollider
(
var w= Window("test", Rect(400, 400, 300, 100)).front;
PopUpTreeMenu(w, Rect(30, 30, 100, 20))
.tree_(
    (
        'a drum': (),
        'bass': (
            'funky': (),
            'tuba': (),
            'unhip': ()
        ),
        'cello': ()
    )
);
)
```
