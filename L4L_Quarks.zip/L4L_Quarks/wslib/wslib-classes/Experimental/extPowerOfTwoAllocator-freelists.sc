+ PowerOfTwoAllocator {
	freeLists { ^freeLists }
	}