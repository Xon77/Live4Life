The files in this folder are redundant manually created HTML and should be
regarded as deprecated since
[SuperCollider version 3.5](https://github.com/supercollider/supercollider/releases/tag/Version-3.5).

See: [News in 3.5](https://doc.sccode.org/Guides/News-3_5.html)

Corresponding schelp source files exist for each class documented by HTML files
in this folder.
