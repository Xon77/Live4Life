# TabbedView2
A Quark for the SuperCollider Programming Language

A feature rich tabbing view. 
