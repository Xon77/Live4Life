//redFrik

//--changes220222
//complete rewrite - hopefully no real breaking changes
//now works inside Layout, supports number and string keys in tree,
//added readme, select animation, icon instead of >, keyboard control,
//added allowsReselection, click once stay open, removed hardcoded font,
//more settings like numFlashes, margin, icon. drag and drop now work.
//--changes220116
//bugfix dark theme black background, use default monospace font
//remove old html help, whitespace cleanup, now Qt only (sc3.6)
//--changes120801
//Qt fix by wouter snoei
//--changes110923
//bugfix for osx 10.6: make sure no windows hidden behind another
//--changes100727
//minor fix to initClass so that new gui schemes (e.g. qt) won't break compilation
//--changes090619
//now using the redirect classes instead of GUI
//took out relativeOrigin and rewrote to use sc3.3.1 userview x/y mouse positions
//--changes090521
//added sortFunc, value_ and valueAction_.  thanks miguel
//--changes090114
//bugfix: userview canfocus now set to false
//--changes080827
//added hiliteColor_
//moved around some methods and added more comments
//andother rewrite of positioning.  bugfix for nested views with decorators.
//--changes080826
//now using SCPopUpMenu instead of SCListView as base. strange mistake
//added GUI.popUpTreeMenu for consistency
//fixed bug in bounds getter
//rewrote positioning. should now work inside views with flowlayout decorators, tabbedview etc
//this also fixed the swingosc offset issues
//--080825
//initial release

PopUpTreeMenu : SCViewHolder {
	var	<>tree, <value, <currentLeaf, <>action, <>openAction, <>closeAction,
	<>hiliteColor,
	>sortFunc,
	<currentPath,
	<>allowsReselection= false,
	<>margin= 4,
	>numFlashes= 1, >flashRate= 0.1,
	<>icon= "▶",
	wdt, hgt, pop, lst,
	xIndexLast, yIndexLast,
	timer, timer2;

	*new {|parent, bounds|
		^super.new.init(parent, bounds);
	}

	init {|argParent, argBounds|
		lst= List.new;  //one dictionary in here for each level
		tree= ();
		currentPath= [];
		currentLeaf= [];
		hiliteColor= QtGUI.palette.highlight;
		timer= 0;
		timer2= 0;
		pop= PopUpMenu(argParent, argBounds)  //visible when menu not open
		.beginDragAction_({|v, x, y| value})
		.canReceiveDragHandler_(true)
		.receiveDragHandler_({|v, x, y|
			var val= View.currentDrag.asString.findRegexp("\\[.+\\]");
			if(val.notEmpty, {
				val= val[0][1];
				while({val.first==$[ or:{val.first==Char.space}}, {
					val= val.drop(1);
				});
				while({val.last==$] or:{val.last==Char.space}}, {
					val= val.drop(-1);
				});
				this.value_(val.split(Char.comma).collect{|x| x.stripWhiteSpace.asSymbol});
			});
		})
		.canFocus_(true)
		.toFrontAction_({
			if(lst.any{|z| z.view.hasFocus}.not, {
				this.prCloseAll;
			});
		})
		.mouseDownAction_({|v, x, y| this.prBegin(x, y)})
		.mouseMoveAction_({|v, x, y|
			var sum= 0, offset;
			var xIndex= lst.detectIndex({|z|
				sum= sum+z.view.bounds.width;
				x<sum;
			});
			if(xIndex.notNil, {  //check that tree is not empty
				offset= lst[xIndex].view.absoluteBounds.top-pop.absoluteBounds.top;
				this.prSelect(xIndex, (y-offset/hgt).asInteger.clip(0, lst[xIndex].items.size-1));
			});
		})
		.mouseUpAction_({|v, x, y|
			this.prEnd(xIndexLast, x, y);
		})
		.keyDownAction_({|v, c, m, u, k, key|
			if(c==Char.space, {
				this.prBegin(0, 0);
			});
		});
		this.view_(pop);
		this.onClose= this.onClose <> {this.prCloseAll};

		if(this.parent.notNil, {
			this.parent.onMove= {this.prCloseAll} <> this.parent.onMove;
		});
	}

	value_ {|path|
		if(this.prCheckPath(tree, path), {
			this.prValue_(path, false);
		});
	}

	valueAction_ {|path|
		if(this.prCheckPath(tree, path), {
			this.prValue_(path, true);
		});
	}

	//--private
	prValue_ {|path, actionFlag|
		value= path;
		if(actionFlag, {action.value(this, value)});
		pop.items_([value.last]);
	}

	prBegin {|x, y|
		var iconSize= icon.bounds(this.font);
		wdt= iconSize.width;
		hgt= iconSize.height;

		openAction.value(this, x, y);

		if(tree.keys.size==0, {
			"%: no leaves found in tree".format(this.class).warn;
			^nil;
		});
		pop.clear;
		timer= Main.elapsedTime;
		this.prOpen(tree, 0, value);
	}

	prSelect {|xIndex, yIndex|
		if(lst.size==0, {  //extra safety
			^nil;
		});

		if(yIndex!=yIndexLast or:{xIndex!=xIndexLast}, {
			this.prCloseAbove(xIndex);

			lst[xIndex].selectedIndex= yIndex;
			lst[xIndex].view.refresh;

			currentPath= this.prLookupKeys(tree, lst);
			if(lst[xIndex].items[yIndex].value, {  //item is a branch?
				this.prOpen(this.prLookupTree(tree, currentPath), yIndex, nil);
				currentLeaf= [];
			}, {
				currentLeaf= currentPath;
			});

			if(xIndex!=xIndexLast or:{currentLeaf.size==0}, {
				lst[xIndex].window.alwaysOnTop_(true).alwaysOnTop_(false);  //workaround for focus issue #4489
				xIndexLast= xIndex;
			});
			yIndexLast= yIndex;
		});
	}

	prEnd {|xIndex, x, y|
		if(lst.size==0, {
			^nil;  //when tree empty
		});

		if(Main.elapsedTime-timer<0.5, {  //single click stay open?
			^nil;
		});

		Routine({
			var val;
			if(currentLeaf.size>0, {  //mouse released on leaf?
				if(allowsReselection or:{currentLeaf!=value}, {
					val= lst[xIndex].selectedIndex;
					numFlashes.do{|i|
						lst[xIndex].selectedIndex= nil;
						lst[xIndex].view.refresh;
						(flashRate/2).wait;
						lst[xIndex].selectedIndex= val;
						lst[xIndex].view.refresh;
						(flashRate/2).wait;
					};
					this.prValue_(currentLeaf, true);
				});
			});
			this.prCloseAll(x, y);
		}).play(AppClock);
	}

	prOpen {|tree, offset, value|
		var window, userView;
		var width, height, x, y, wh, scroll;
		var items;  //array of associations
		var selectedIndex;  //integer. nil when nothing selected
		var treeStruct= IdentityDictionary.new;
		var xIndex= lst.size;
		var n= value.first.asSymbol;

		tree.keysValuesDo{|k, v| treeStruct.put(k.asSymbol, v.size>0)};
		items= treeStruct.keys.asArray.sort(sortFunc).collect{|k, i|
			if(k==n, {selectedIndex= i});
			(k -> treeStruct[k])
		};

		width= items.maxValue{|a| a.key.asString.bounds(this.font).width}+(margin*3)+wdt;
		height= items.size*hgt;

		if(lst.size==0, {  //root?
			x= this.absoluteBounds.left;
			y= this.absoluteBounds.top;
			offset= offset-(selectedIndex?0);
			width= width.max(this.bounds.width);
		}, {
			x= lst.last.window.bounds.right;
			y= lst.last.view.absoluteBounds.top;
		});
		x= x.min(Window.screenBounds.width-width);
		y= (Window.screenBounds.height-y-height-(offset*hgt)).max(0);
		scroll= height>Window.screenBounds.height;
		wh= height.min(Window.screenBounds.height);

		window= Window("", Rect(x, y, width, wh), false, false, scroll: scroll)
		.acceptsMouseOver_(true)
		.background_(this.background)
		.userCanClose_(false)
		.toFrontAction_({
			if(Main.elapsedTime-timer2>0.01, {
				lst.do{|z| z.window.front};  //make sure visibility in order
			});
			timer2= Main.elapsedTime;
		});

		userView= UserView(window, Size(width, height))
		.drawFunc_({
			var i;
			if(lst[xIndex].notNil, {  //extra safety
				i= lst[xIndex].selectedIndex;
				if(i.notNil, {
					Pen.fillColor= hiliteColor;
					Pen.fillRect(Rect(0, i*hgt, width, hgt));
				});
				Pen.font= this.font;
				Pen.fillColor= pop.stringColor;
				items.do{|a, i|
					Pen.stringAtPoint(a.key, Point(margin, i*hgt));
					if(a.value, {
						Pen.stringAtPoint(icon, Point(width-wdt-margin, i*hgt));
					});
				};
			});
		})
		.keyDownAction_({|v, c, m, u, k, key|
			case
			{key==0x01000014} {  //right
				if(xIndex+1<lst.size, {
					this.prSelect(xIndex+1, 0);
				});
			}
			{key==0x01000012} {  //left
				if(xIndex>0, {
					this.prSelect(xIndex-1, lst[xIndex-1].selectedIndex);
				});
			}
			{key==0x01000013} {  //up
				this.prSelect(xIndex, (yIndexLast??{yIndexLast= selectedIndex ? 1}-1).max(0));
			}
			{key==0x01000015} {  //down
				this.prSelect(xIndex, (yIndexLast??{yIndexLast= selectedIndex ? -1}+1).min(items.size-1));
			}
			{key==0x01000004} {  //return
				this.prEnd(xIndex, 0, 0);
			}
			{key==0x01000000} {  //esc
				this.prCloseAll;
			};
		})
		.mouseOverAction_({|v, x, y| this.prSelect(xIndex, (y/hgt).asInteger)})
		.mouseUpAction_({|v, x, y| this.prEnd(xIndex, x, y)});

		lst.add((
			window: window,
			view: userView,
			items: items,
			selectedIndex: selectedIndex
		));

		window.front;
		if(value.size>1, {
			if(tree[value.first].notNil, {  //safety for changing tree
				this.prOpen(tree[value.first], selectedIndex, value.drop(1));
			});
		});
	}

	prCloseAll {|x, y|
		if(lst.size>0, {
			currentPath= [];
			currentLeaf= [];
			lst.do{|z| z.window.close};
			lst= List.new;
			xIndexLast= nil;
			yIndexLast= nil;
			if(value.size>0, {
				pop.items_([value.last]);
			});
			closeAction.value(this, x, y);
		});
	}

	prCloseAbove {|index|
		if(lst.size>(index+1), {
			lst.pop.window.close;
			this.prCloseAbove(index);
		});
	}

	prCheckPath {|tree, path|
		var p= path.first;
		var subTree= tree[p];
		if(subTree.isNil, {
			"%: % '%' does not exist".format(
				this.class.name,
				if(path.size>1, {"branch"}, {"leaf"}),
				p
			).warn;
		}, {
			if(subTree.size>0, {
				if(path.size==1, {
					"%: '%' is a branch".format(this.class.name, p).warn;
				}, {
					^this.prCheckPath(subTree, path.drop(1));
				});
			}, {
				if(path.size==1, {
					^true;
				});
				"%: superfluous args: %".format(this.class.name, path.drop(1)).warn;
			});
		});
		^false;
	}

	prLookupKeys {|tree, lst|
		var n= lst[0].items[lst[0].selectedIndex].key;
		var key= tree.keys.asArray.detect{|k| k.asSymbol==n};
		^if(lst.size>1, {
			[key]++this.prLookupKeys(tree[key], lst.drop(1));
		}, {
			[key];
		});
	}

	prLookupTree {|tree, path|
		var n= path[0].asSymbol;
		var key= tree.keys.asArray.detect{|k| k.asSymbol==n};
		^if(path.size>1, {
			this.prLookupTree(tree[key], path.drop(1));
		}, {
			tree[key];
		});
	}
}
