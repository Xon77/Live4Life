# TabbedView
A Quark for the SuperCollider Programming Language

deprecated. Please use TabbedView2 instead.
an array of CompositeViews (or ScrollViews) with tabs for switching

